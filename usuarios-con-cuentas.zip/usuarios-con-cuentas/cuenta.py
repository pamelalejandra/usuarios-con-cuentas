class Cuenta_bancaria:
    def __init__ (self, tasa_interes, balance):
        self.tasa_interes = tasa_interes
        self.balance = balance
        self.balance_cuenta = balance

    def deposito (self, amount):
        self.balance_cuenta += amount
        return self

    def retiro(self,amount):
        self.balance_cuenta -= amount
        if self.balance_cuenta <= 100:
            print ('Fondos insuficientes: Su saldo es menor a $100 se le cobrará una tarifa de $5')
            self.balance_cuenta -= 5
        return self

    def mostrar_info_cuenta (self):
        print('Balance:'+' '+'$'+ str(self.balance_cuenta))
        return self

    def generar_interes (self):
        if self.balance_cuenta > 0 :
            self.balance_cuenta += self.balance_cuenta*(self.tasa_interes/100)
        return self