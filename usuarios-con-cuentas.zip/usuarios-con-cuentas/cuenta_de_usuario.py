from cuenta import Cuenta_bancaria

class User:
    def __init__(self, name, email_address, tasa_interes, balance_inicial):
        self.name = name
        self.email = email_address
        self.account_balance = 0
        self.cuentas = []
        self.cuentas.append(Cuenta_bancaria(tasa_interes=tasa_interes, balance=balance_inicial))

    def deposito(self, amount):
        self.cuentas[0].deposito(amount)
        return self

    def retiro(self, amount):
        self.cuentas[0].retiro(amount)
        return self

    def balance_cuenta(self):
        return self.cuentas[0].balance

    def mostrar_info_usuario(self):
        print("Nombre: ", self.name)
        print("Correo electrónico: ", self.email)
        print("Saldo de la cuenta: ", self.balance_cuenta())

    def transferir_dinero(self, other_user, amount):
        self.cuentas[0].retiro(amount)
        other_user.cuentas[0].deposito(amount)
        return self

    def generar_interes(self):
        self.cuentas[0].generar_interes()
        return self

    def nueva_cuenta(self, tasa, balance_inicial):
        self.cuentas.append(Cuenta_bancaria(tasa_interes=tasa, balance=balance_inicial))
        return self
    
alejandra = User("Alejandra R.", "alejandra@python.com", 10, 200)
natalia = User("Natalia R.", "natalia@python.com", 5, 500)
claudia = User("Claudia R.", "claudia@python.com", 10, 2000)

alejandra.deposito(300).deposito(100).deposito(50).retiro(300).mostrar_info_usuario()
alejandra.transferir_dinero(claudia, 200).mostrar_info_usuario()
natalia.deposito(500).deposito(200).retiro(200).retiro(200).mostrar_info_usuario()
claudia.deposito(800).retiro(200).retiro(500).retiro(300).mostrar_info_usuario()